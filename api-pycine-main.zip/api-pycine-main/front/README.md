# Front (appcine)

- [front (svelte)](https://github.com/fscheidt/front)
- [pycine (fastapi)](https://github.com/fscheidt/pycine)
- [web4 - 2023](https://github.com/fscheidt/web4-23)

## Creating a project

```bash
# create a new project in front folder
npm create svelte@latest front
npm run dev
```

