<script>
    let data = {
      "biography": "Arnold Alois Schwarzenegger (born July 30, 1947) is an Austrian-American actor, film producer, businessman, former bodybuilder and politician who served as the 38th governor of California (2003-2011). As of 2022, he is the most recent Republican governor of California. Time magazine named Schwarzenegger one of the 100 most influential people in the world in 2004 and 2007. He also served as ...",
      "birthday": "1947-07-30",
      "gender": 2,
      "id": 1100,
      "known_for_department": "Acting",
      "name": "Arnold Schwarzenegger",
      "place_of_birth": "Thal, Styria, Austria",
      "popularity": 26.296,
      "profile_path": "/zEMhugsgXIpnQqO31GpAJYMUZZ1.jpg"
    }

    
    </script>
    
    <h2>{data.name}</h2>
    
    <p>{data.biography}</p>