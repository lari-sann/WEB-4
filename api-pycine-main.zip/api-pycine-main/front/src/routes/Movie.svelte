<script>
	let promise = getFilmes();
  
	async function getFilmes() {
	  const res = await fetch(`http://localhost:8000/filmes`);
	  const text = await res.json();
	  if (res.ok) {
		return text;
	  } else {
		throw new Error(text);
	  }
	}
  
	function handleClick() {
	  promise = getFilmes();
	}
  
	async function favoritarFilme(tmdbId, title) {
	  const res = await fetch(`http://localhost:8000/favoritos/`, {
		method: 'POST',
		headers: {
		  'Content-Type': 'application/json'
		},
		body: JSON.stringify({ user_id: "1", tmdb_id: tmdbId.toString(), title: title })
	  });
  
	  if (res.ok) {
		alert('Filme adicionado aos favoritos com sucesso!');
	  } else {
		alert('Erro ao adicionar filme aos favoritos.');
	  }
	}
</script>
  
  <button on:click={handleClick}> Carregar filmes... </button>
  
  <!-- svelte-ignore missing-declaration -->
  {#await promise}
	<p>Carregando........</p>
  {:then filmes}
	<h1>Lista de filmes</h1>
	<div class="filme-container">
	  {#each filmes as filme}
		<div class="filme">
		  <p>{filme.title}</p>
		  <img src="{filme.image}" alt="">
		  <button type="button" on:click={() => favoritarFilme(filme.id, filme.title)}>Adicionar aos favoritos</button>
		</div>
	  {/each}
	</div>
	<!-- <p>{filmes.title}</p> -->
  {:catch error}
	<p style="color: red">{error.message}</p>
  {/await}

<style>
	.filme-container {
	  display: flex;
	  flex-wrap: wrap;
	  justify-content: space-around;
	}
  
	.filme {
	  width: 200px; /* Ajuste conforme necessário */
	  margin: 10px;
	  text-align: center;
	}
  
	img {
	  max-width: 100%;
	  height: auto;
	  display: block;
	  margin-bottom: 10px;
	}
  
	button {
	  display: block;
	  margin-top: 10px;
	}
</style>
  