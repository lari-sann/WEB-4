<script>
    let filmes = [];
  
    async function sendForm() {
      const title = document.getElementById("title").value;
      const res = await fetch(`http://localhost:8000/filmes/${title}`);
      const json = await res.json();
      filmes = json;
    }
  
    async function favoritarFilme(tmdbId, title) {
      const res = await fetch(`http://localhost:8000/favoritos/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ user_id: "1", tmdb_id: tmdbId.toString(), title: title })
      });
  
      if (res.ok) {
        alert('Filme adicionado aos favoritos com sucesso!');
      } else {
        alert('Filme já favoritado!');
      }
    }
</script>
  
<form class="crud" on:submit|preventDefault={sendForm}>
    <input type="text" id="title" name="title" placeholder="Título do Filme" required autocomplete="off">
    <input type="submit" value="buscar">
</form>
  
  {#if filmes.length > 0}
    <h1>Lista dos Filmes</h1>
    <div class="filme-container">
      {#each filmes as filme}
        <div class="filme">
          <p>Nome do Filme: {filme.title}</p>
          <p>ID do Filme: {filme.id}</p>
          <img src="{filme.image}" alt="">
          <button type="button" on:click={() => favoritarFilme(filme.id, filme.title)}>Adicionar aos favoritos</button>
        </div>
      {/each}
    </div>
  {:else}
    <p>ERROR Nenhum filme encontrado.</p>
  {/if}

<style>
    .filme-container {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-around;
    }
  
    .filme {
      width: 200px; /* Ajuste conforme necessário */
      margin: 10px;
      text-align: center;
    }
  
    img {
      max-width: 100%;
      height: auto;
      display: block;
      margin-bottom: 10px;
    }
  
    button {
      display: block;
      margin-top: 10px;
    }
</style>
  